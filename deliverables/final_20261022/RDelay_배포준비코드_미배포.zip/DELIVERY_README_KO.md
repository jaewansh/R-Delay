# 별도 공개 배포 준비 소스 - 미배포

기준 커밋: 1d1d61f68d4fdeb3e2fa48b9b34965e4b013f623
문서 버전 v0.3과 서비스 코드 버전0.2는 별개다.

R-Delay/에 실제 저장소 전체 소스가 있다. 기존 v0.1 문서는 이력을 보존한 것이며 최신 기획서는 별도 전달된 v0.3 파일이다.

실행: R-Delay 폴더에서 `python -m pip install -r requirements-service.txt` 다음 `python -m uvicorn api.main:app --host 127.0.0.1 --port 8000`. 브라우저에서 http://127.0.0.1:8000.

GitHub Pages/Pyodide 실행은 아직 구현되지 않았다. 공개 URL도 생성되지 않았다. 합성 시제품이며 현장 예측력·비용절감·고객 구매는 미검증이다.
